# Automate-the-functionality-to-explore-the-MamaEarth-website
https://mamaearth.in/ Check if you are landed on the correct page Print the URL and title of the page Click on Face &lt; Face Wash Click on sort by Tea tree face wash Select any Face wash Now Click on the hair &lt; Conditioner Click on sort by Henna Select any Conditioner and add to cart
